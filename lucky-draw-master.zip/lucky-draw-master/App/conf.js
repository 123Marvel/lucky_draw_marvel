module.exports = {
    preloadCandidates: []
};